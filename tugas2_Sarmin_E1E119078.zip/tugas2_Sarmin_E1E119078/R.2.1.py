# 1. Flight controllers
# 2. Nuclear reactor controllers
# 3. Life support computers aboard spacecrafts